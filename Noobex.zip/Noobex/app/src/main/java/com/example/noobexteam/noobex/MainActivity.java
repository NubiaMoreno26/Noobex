package com.example.noobexteam.noobex;

import android.content.Intent;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class MainActivity extends AppCompatActivity {

    EditText cod;
    Button cons;
    TextView ras,des;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cod=(EditText) findViewById(R.id.etCod);
        ras=(TextView) findViewById(R.id.txtRas);
        des=(TextView) findViewById(R.id.txtDes);
        cons = (Button) findViewById(R.id.btnCons);

        cons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(MainActivity.this, Consulta.class);
                startActivity(in);
                consultar();
            }
        });

    }

    public  Connection conexionBD(){
        Connection cnn=null;
        try{
            StrictMode.ThreadPolicy politica = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(politica);

            Class.forName("net.sourceforge.jtds.jdbc.Driver").newInstance();
            cnn = DriverManager.getConnection("jdbc:jtds:sqlserver://127.0.0.1;databaseName=practicadb;user=root;password=Be1418;");

        }catch (Exception e){
            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        return  cnn;
    }

    public void consultar(){
        try {
            Statement stm = conexionBD().createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM paquete WHERE id ='" + cod.getText().toString() + "'");

            if(rs.next()){
                ras.setText(rs.getString(2));
                des.setText(rs.getString(1));

            }
            cod.setText("");

        }catch(Exception e){
            Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }

}
